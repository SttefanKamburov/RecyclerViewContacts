package com.example.recyclerviewcontacts;


import android.os.Bundle;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class BlankFragment extends DialogFragment {
    private EditText editText;

    public BlankFragment() {
        // Required empty public constructor
    }

    public static BlankFragment newInstance(String title) {
        BlankFragment frag = new BlankFragment();
        Bundle args = new Bundle();
        args.putString("title", title);
        frag.setArguments(args);
        return frag;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_blank, container, false);
    }

    public void onViewCreated(View view,  Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Извличане на елементите от изгледа
        editText = view.findViewById(R.id.textView2);
        // Поставяне на заглавие
        String title = getArguments().getString("title", "Enter Name");
        getDialog().setTitle(title);
        // Фокуситане на курсора за писане върху еditText
        editText.requestFocus();
        // Автоматично показване на клавиятурата
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    public void onClick(View view){
        String name = view.findViewById(R.id.textView2).toString();
        String adress = view.findViewById(R.id.textView3).toString();
       // getActivity().getResult(name,adress);


    }
}
