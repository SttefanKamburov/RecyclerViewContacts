package com.example.recyclerviewcontacts;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class ContactView extends RecyclerView.ViewHolder {
    private TextView contact;

    public ContactView(View itemView){
        super(itemView);
        contact =itemView.findViewById(R.id.textView);
    }
    public void setContact(String contact){
        this.contact.setText(contact);
    }



}
