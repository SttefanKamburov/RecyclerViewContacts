package com.example.recyclerviewcontacts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ContactAdapter extends RecyclerView.Adapter<ContactView> {
    private List<Contact>contacts;
    private Context context;

    public ContactAdapter(List<Contact>contacts){this.contacts=contacts;}

    public ContactView onCreateViewHolder(ViewGroup parent, int viewType){
        context=parent.getContext();
        LayoutInflater inflater=LayoutInflater.from(context);
        View contactView = inflater.inflate(R.layout.card_view,parent,false);
        ContactView viewHolder = new ContactView((contactView));
        return viewHolder;
    }

    public void onBindViewHolder(ContactView holder,int position){
        final Contact contact =contacts.get(position);
        holder.setContact(" Name "+contact.getName()+" Adress "+contact.getAddress());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, contact.getName() + ", " + contact.getAddress() , Toast.LENGTH_SHORT).show();
            }
        });
    }

    public int getItemCount(){
        return contacts.size();
    }
}
