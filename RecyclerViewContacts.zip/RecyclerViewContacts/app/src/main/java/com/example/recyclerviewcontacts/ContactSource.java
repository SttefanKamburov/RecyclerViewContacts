package com.example.recyclerviewcontacts;

import java.util.ArrayList;

public class ContactSource {
    private ArrayList<Contact>contacts;

    public static ArrayList<Contact> generateContactList(){
        ArrayList<Contact>contacts=new ArrayList<Contact>();
        contacts.add(new Contact("street 9","Ivan"));
        contacts.add(new Contact("street 7","Pesho"));
        contacts.add(new Contact("street 123","Gosho"));
        return contacts;
    }

    public void addContact(String address,String name){
        contacts.add(new Contact(address,name));
    }
}
